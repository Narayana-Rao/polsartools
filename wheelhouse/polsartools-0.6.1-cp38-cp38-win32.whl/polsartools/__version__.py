# polsartools/__version__.py
__version__ = "0.6.1"
