def calibrate(data_array):
    """
    Applies radiometric calibration to the data array.
    """
    # Example calibration: scale the data
    return data_array * 1.0
