"""
polsartools - A package for geospatial raster data processing.
"""
# polsartools/__init__.py

__version__ = '0.1.0'  # Replace with your current version