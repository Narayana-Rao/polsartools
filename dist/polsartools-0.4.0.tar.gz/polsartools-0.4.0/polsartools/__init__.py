"""
polsartools - A package for geospatial raster data processing.
"""
# polsartools/__init__.py


import warnings
warnings.filterwarnings("ignore")


__version__ = '0.4.0'  # Replace with your current version

from . import polsar